// This file is intentionally left blank.
// All data is now fetched from the Flask backend API.
